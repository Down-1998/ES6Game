import {Map,width,height,player,wall,space,box,correct} from './map.js';

/**
 *
 * @param direction按照指定的方向进行行走  left  right up  down
 */
export function playerMove(direction) {
    //得到玩家的位置
    let playerLoaction = getPlayerLocation();
    // console.log(playerLoaction);
    //得到玩家的下一个位置
    let nextInfo = getNextInfo(playerLoaction.row,playerLoaction.col,direction);
    // console.log(nextInfo);

    //不能移动
    if (nextInfo.value == wall){
       return false;
    }
    //能移动
    if (nextInfo.value == space){
        exchange(playerLoaction,nextInfo);
        return true;
    }else {
        //下一个位置是箱子
        //看箱子的下一个位置
        let nextnextInfo = getNextInfo(nextInfo.row,nextInfo.col,direction);
        if (nextnextInfo.value == space){
            //可以移动
            exchange(nextInfo,nextnextInfo);
            exchange(playerLoaction,nextInfo);
            return true;
        }else {
            return false;
        }
    }
}

/**
 * 根据当前地图内容判断是否游戏胜利
 */
export function isWin() {
    //是否每个正确位置都有箱子
    for (let i = 0; i < correct.length; i++){
        let point = correct[i];
        if (Map[point.row][point.col] !== box){
            return false;
        }
    }
    return true;

}
//移动,改变map地图
function exchange(point1,point2) {
    let temp = Map[point1.row][point1.col];
    Map[point1.row][point1.col] = Map[point2.row][point2.col];
    Map[point2.row][point2.col] = temp;
}

/**
 * 得到玩家的位置
 */
function getPlayerLocation() {
    for (let i = 0; i < height; i ++){
        for (let j = 0; j < width; j ++){
            if (Map[i][j] == player){
                return{
                    row:i,
                    col:j
                }
            }
        }
    }
    throw new Error('地图有问题,没有找到玩家');
}

/**
 *得到指定方向上的下一个位置的信息
 * @param direction
 */
function getNextInfo(row, col, direction) {
    if (direction == 'left') {
        return {
            row: row,
            col: col - 1,
            value: Map[row][col - 1]
        }
    }else if (direction == 'right'){
        return {
            row: row,
            col:col + 1,
            value: Map[row][col + 1]
        }
    }else if (direction == 'up'){
        return {
            row: row - 1,
            col:col,
            value: Map[row - 1][col]
        }
    }else if (direction == 'down'){
        return {
            row: row + 1,
            col:col,
            value: Map[row + 1][col]
        }
    }

}
import {playerMove,isWin} from "./play.js";
import ShowUi from './ui.js';
ShowUi();
let over = false;
//完成整个游戏
window.onkeydown = function (e) {
    if (over){
        return;
    }
    var result = false;
    if (e.key === "ArrowUp") {
        result = playerMove("up");
    }
    else if (e.key === "ArrowDown") {
        result = playerMove("down")
    }
    else if (e.key === "ArrowLeft") {
        result = playerMove("left")
    }
    else if (e.key === "ArrowRight") {
        result = playerMove("right")
    }

    if (result) {
        ShowUi();
        if (isWin()){
            console.log('游戏结束,你通关了!');
            over = true;
        }
    }
}
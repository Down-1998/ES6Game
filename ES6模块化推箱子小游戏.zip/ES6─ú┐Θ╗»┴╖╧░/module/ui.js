/*
* 用于将地图显示到界面上
* */
import * as map from './map.js';

let divContainer = document.getElementById('game');
let pieceWidth = 45;
let pieceHeight = 45;

//设置div的宽度和高度
function setDivcontainer() {
    divContainer.style.width = map.Map[0].length * pieceWidth + 'px';
    divContainer.style.height = map.Map.length * pieceHeight + 'px';
}
//判断一个位置是否为正确位置
function isCorrect(i,j) {
    for (let k = 0; k < map.correct.length; k++){
        if (map.correct[k].row == i && map.correct[k].col == j){
            return true;
        }
    }
    return false;
    // return map.correct.find(point=>point.row == i && point.col == j) != undefined;
}

//设置地图每一个小块
function setOnePiece(i, j) {
    let value = map.Map[i][j];//取出地图相应位置的值
    let correct = isCorrect(i,j);
    const div = document.createElement('div');
    div.className = 'item';
    //调整div的位置
    div.style.left = j * pieceWidth + 'px';
    div.style.top = i * pieceHeight + 'px';
    // div.style.border = '1px solid';
    if (value === map.player){
        div.classList.add('player');
    }else if (value === map.wall){
        div.classList.add('wall');
    }else if (value === map.box){
        if (correct){
            div.classList.add('correct-box');
        }else {
            div.classList.add('box');
        }
    }else {//空白位置
        if (correct){
            div.classList.add('correct');
        }else {
            return;
        }
    }
    divContainer.appendChild(div);
}

//根据地图在页面上设置相应的元素
function setMap() {
//1.清空容器
    divContainer.innerHTML = '';
//    2.遍历地图的内容
    for (let i = 0; i < map.height; i++) {//i是行数j是列数
        for (let j = 0; j < map.width; j++) {
            setOnePiece(i, j);

        }
    }
}

//该函数用于显示地图
export default function () {
    //设置div的宽度和高度
    setDivcontainer();
    setMap();

}